﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 ChenJi.rc 使用
//
#define IDD_CHENJI_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDC_EDIT1                       1000
#define IDC_COMBO1                      1001
#define IDC_LIST1                       1002
#define IDC_RADIO1                      1003
#define IDC_RADIO2                      1004
#define IDC_RADIO3                      1005
#define IDC_RADIO4                      1006
#define IDC_BUTTON1                     1007
#define IDC_BUTTON2                     1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
