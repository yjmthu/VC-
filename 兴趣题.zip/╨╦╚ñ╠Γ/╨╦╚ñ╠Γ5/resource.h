//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� MineClearance.rc ʹ��
//
#define IDD_MINECLEARANCE_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_MENU              128
#define IDR_MAINFRAME_ICON              128
#define IDR_MENU1                       130
#define IDI_ICON_MINE                   132
#define IDB_BITMAP1                     134
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_32774                        32774
#define ID_32775                        32775
#define ID_1010                         32776
#define ID_2030                         32777
#define ID_3040                         32778
#define ID_32784                        32779
#define ID_32785                        32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
