﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 Calculator.rc 使用
//
#define IDD_CALCULATOR_DIALOG           102
#define IDI_ICON1                       132
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_BUTTON3                     1004
#define IDC_BUTTON4                     1005
#define IDC_BUTTON5                     1006
#define IDC_BUTTON7                     1008
#define IDC_BUTTON8                     1009
#define IDC_BUTTON9                     1010
#define IDC_BUTTON10                    1011
#define IDC_BUTTON11                    1012
#define IDC_BUTTON12                    1013
#define IDC_BUTTON13                    1014
#define IDC_BUTTON14                    1015
#define IDC_BUTTON15                    1016
#define IDC_BUTTON16                    1017
#define IDC_BUTTON17                    1018
#define IDC_BUTTON18                    1019
#define IDC_BUTTON19                    1020
#define IDC_BUTTON20                    1021
#define IDC_BUTTON21                    1022
#define IDC_BUTTON22                    1023
#define IDC_BUTTON23                    1024
#define IDC_BUTTON24                    1025
#define IDC_BUTTON25                    1026
#define IDC_BUTTON26                    1027
#define IDC_BUTTON27                    1028
#define IDC_BUTTON28                    1029
#define IDC_BUTTON29                    1030
#define IDC_BUTTON36                    1031
#define IDC_BUTTON31                    1032
#define IDC_BUTTON32                    1033
#define IDC_BUTTON33                    1034
#define IDC_BUTTON35                    1036
#define IDC_BUTTON30                    1037
#define IDC_BUTTON37                    1038
#define IDC_BUTTON38                    1039
#define IDC_BUTTON39                    1040
#define IDC_BUTTON40                    1041
#define IDC_BUTTON41                    1042
#define IDC_BUTTON42                    1043
#define IDC_BUTTON43                    1044
#define IDC_BUTTON44                    1045
#define IDC_BUTTON45                    1046
#define IDC_BUTTON46                    1047

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
